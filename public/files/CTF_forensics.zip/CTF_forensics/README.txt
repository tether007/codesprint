Backup created before reset.
Some files may be incomplete.




This phone wasn’t lost dramatically.
No cracked screen. No dead battery.
It simply stopped syncing one day.
The owner used it briefly, moved around the city, and then cleared most of what felt unnecessary. Photos were gone. 
Apps were removed. But something remained — the kind of data nobody thinks twice about.
But it has a habit of remembering.

**flag format = CTF{place_digit}


**Notes

Not every folder here is meant to be used

Not every file here is meant to be read

The important things are usually hidden , so look carefully